
<input type="checkbox" name="" id="nav-toggle">
<div class="sidebar">
        <div class="sidebar-brand">
            <h2><span class="lab la-accusoft"></span><span>Admin</span></h2>
        </div>
        <div class="sidebar-menu">
            <ul>
                <li>
                    <a href="<?=base_url();?>admin/home" class="active"><span class="las la-igloo"></span><span>Dashboard</span></a>
                </li>
                <li>
                    <a class="" href="<?=base_url();?>admin/buatundangan"><span class="las la-users"></span><span>Buat Undangan</span></a>
                </li>
                <li>
                    <a class=""  href="<?=base_url();?>admin/ucapandoa"><span class="las la-clipboard-list"></span><span>Ucapan & Do'a</span></a>
                </li>
                
            </ul>
        </div>
</div>